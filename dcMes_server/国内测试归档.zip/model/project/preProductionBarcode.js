const mongoose = require("mongoose");

const preProductionBarcodeSchema = new mongoose.Schema({
    // 工单信息
    workOrderId: { type: mongoose.Schema.ObjectId, ref: "production_plan_work_order" }, // 关联工单
    workOrderNo: { type: String, required: true }, // 工单号
    
    // 物料信息
    materialId: { type: mongoose.Schema.ObjectId, ref: "k3_BD_MATERIAL" }, // 关联物料
    materialNumber: { type: String, required: true }, // 物料编码
    materialName: { type: String, required: true }, // 物料名称
    
    // 添加产线信息
    productionLineId: { type: mongoose.Schema.ObjectId, ref: "production_line" }, // 关联产线
    lineNum: { type: String }, // 产线编码
    
    // 条码规则信息
    ruleId: { type: mongoose.Schema.ObjectId, ref: "barcodeSegmentRule" }, // 关联条码规则
    ruleName: { type: String, required: true }, // 规则名称
    ruleCode: { type: String, required: true }, // 规则编码
    
    // 条码信息
    barcode: { type: String, required: true }, // 生成的基础条码
    printBarcode: { type: String, required: true }, // 基础打印条码
    transformedBarcode: { type: String }, // 转换后的条码
    transformedPrintBarcode: { type: String }, // 转换后的打印条码
    
    // 段落明细
    segmentBreakdown: [{
        name: String, // 段落名称
        value: String, // 原始值
        transformedValue: String, // 转换值
        config: {
            prefix: String, // 前缀
            suffix: String, // 后缀
            showPrefix: Boolean, // 是否显示前缀
            showSuffix: Boolean // 是否显示后缀
        }
    }],
    
    serialNumber: { type: Number, required: true }, // 序号（用于排序）
    
    // 状态信息
    status: { 
        type: String, 
        enum: ['PENDING', 'USED', 'VOIDED', 'SUSPENDED'], // 待使用、已使用、已作废、已暂停
        default: 'PENDING'
    },
    // 批次号
    batchNo: { type: String },
    
    // 作废信息
    voidReason: { type: String }, // 作废原因
    voidBy: { type: String }, // 作废人
    voidAt: { type: Date }, // 作废时间
    
    // 暂停信息
    suspendReason: { type: String }, // 暂停原因
    suspendBy: { type: String }, // 暂停人
    suspendAt: { type: Date }, // 暂停时间
    
    // 使用信息
    usedAt: { type: Date }, // 使用时间
    usedBy: { type: String }, // 使用人
    
    // 基础字段
    remark: { type: String }, // 备注
    creator: { type: String },
    createAt: { type: Date, default: Date.now },
    updater: { type: String },
    updateAt: { type: Date, default: Date.now }
});

// 添加索引
preProductionBarcodeSchema.index({ workOrderNo: 1 });
preProductionBarcodeSchema.index({ barcode: 1 });
preProductionBarcodeSchema.index({ printBarcode: 1 });
preProductionBarcodeSchema.index({ transformedBarcode: 1 });
preProductionBarcodeSchema.index({ transformedPrintBarcode: 1 });
preProductionBarcodeSchema.index({ materialNumber: 1 });
preProductionBarcodeSchema.index({ status: 1 });
preProductionBarcodeSchema.index({ createAt: -1 });
// 列表常用：按创建时间+序号排序，避免大 skip 时内存排序超 32MB 报错
preProductionBarcodeSchema.index({ createAt: -1, serialNumber: -1 });

// 添加新的索引
preProductionBarcodeSchema.index({ lineNum: 1 });
preProductionBarcodeSchema.index({ productionLineId: 1 });
preProductionBarcodeSchema.index({ batchNo: 1 });

// 添加pre-save中间件，自动更新updateAt字段
preProductionBarcodeSchema.pre('save', function(next) {
  // 只在文档被修改时更新updateAt字段
  if (this.isModified() && !this.isNew) {
    this.updateAt = new Date();
  }
  next();
});

// 添加pre-updateOne中间件，自动更新updateAt字段
preProductionBarcodeSchema.pre(['updateOne', 'findOneAndUpdate'], function() {
  // 确保所有updateOne和findOneAndUpdate操作都包含updateAt
  if (this.getUpdate() && !this.getUpdate().$set?.updateAt) {
    if (!this.getUpdate().$set) {
      this.getUpdate().$set = {};
    }
    this.getUpdate().$set.updateAt = new Date();
  }
});

module.exports = mongoose.model("preProductionBarcode", preProductionBarcodeSchema); 