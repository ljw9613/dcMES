const mongoose = require("mongoose");

const productDiNum = new mongoose.Schema(
  {
    productId: { type: mongoose.Schema.ObjectId, ref: "k3_BD_MATERIAL" },
    diNum: { type: String, maxlength: 100, default: null, description: "DI码" },
    createBy: { type: String }, // 创建人pp
    updateBy: { type: String }, // 更新人
    createAt: { type: Date, default: Date.now }, // 创建时间
    updateAt: { type: Date, default: Date.now } // 更新时间
  },
  {
    timestamps: { createdAt: "createTime", updatedAt: "updateTime" }, // 自动维护时间字段
    collection: "product_di_number", // 指定集合名称
  }
);

// 按 DI 码 + 产品查询索引，避免 COLLSCAN（日志中扫 318 条达 63s）
productDiNum.index({ diNum: 1, productId: 1 }, { background: true, name: "idx_diNum_productId" });

module.exports = mongoose.model("productDiNum", productDiNum);
